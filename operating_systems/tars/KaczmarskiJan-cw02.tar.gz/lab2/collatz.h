int collatz_conjecture(int input);
void test_collatz_convergence(int input, int max_iter, int *steps);

