INSERT INTO "Languages" ("LanguageID","LanguageName")
VALUES
(1,'Hiri Motu'),
(2,'Telugu'),
(3,'Armenian'),
(4,'Afrikaans'),
(5,'Afrikaans'),
(6,'Indonesian'),
(7,'English');
