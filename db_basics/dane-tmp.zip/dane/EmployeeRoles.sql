INSERT INTO "EmployeeRoles" ("RoleID","RoleName")
VALUES
(1,'Professor'),
(2,'Admissions'),
(3,'Research'),
(4,'Dean'),
(5,'Department chair'),
(6,'Administration');
